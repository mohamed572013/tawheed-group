<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>عيون المشاعر</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="./assets/images/icon.png">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/normalize.css">
    <link rel="stylesheet" href="./assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="./assets/css/icomoon.css">
    <link rel="stylesheet" href="./assets/css/owl.carousel.css">
    <link rel="stylesheet" href="./assets/css/bootstrap-select.css">
    <link rel="stylesheet" href="./assets/css/scrollbar.css">
    <link rel="stylesheet" href="./assets/css/jquery.mmenu.all.css">
    <link rel="stylesheet" href="./assets/css/prettyPhoto.css">
    <link rel="stylesheet" href="./assets/css/transitions.css">
    <link rel="stylesheet" href="./assets/css/main.css">
    <link rel="stylesheet" href="./assets/css/color.css">
    <link rel="stylesheet" href="./assets/css/hover.css">
    <!-- Current Page Styles -->
    <link rel="stylesheet" type="text/css" href="./assets/revolution_slider/css/settings.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="./assets/revolution_slider/css/style.css" media="screen" />
    <link rel="stylesheet" href="./assets/css/responsive.css">
    <link rel="stylesheet" href="./assets/WOW-master/css/libs/animate.css">
    <link rel="stylesheet" href="./assets/css/customs_en.css">
    <script src="./assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
</head>