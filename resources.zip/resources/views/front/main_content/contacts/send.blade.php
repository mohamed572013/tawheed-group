<div>
    Name is :
    {{ $name }}
</div>
<div>
    Email is :
    {{ $email }}
</div>
<div>
    Message is : 
    {{ $content }}
</div>