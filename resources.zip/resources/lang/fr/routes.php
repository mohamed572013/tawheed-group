<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// resources/lang/es/routes.php
return [
    "about" => "acerca",
    "view" => "ver/{id}", //we add a route parameter
        // other translated routes
];
