<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Programservice extends Model {

    public $table = "programservices";

}
