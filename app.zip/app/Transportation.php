<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Description of Transportation
 *
 * @author mhmudhsham
 */
class Transportation extends Model {

    public $table = "transportations";

}
