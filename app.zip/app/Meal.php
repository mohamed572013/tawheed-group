<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Description of Meal
 *
 * @author mhmudhsham
 */
class Meal extends Model {

    public $table = "meals";

}
