<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Description of Nationality
 *
 * @author mhmudhsham
 */
class Nationality extends Model {

    public $table = "nationalities";

}
